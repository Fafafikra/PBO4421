class Mobil{
    var warna =""
        var tahunproduksi =0
}
fun main(args: Array<String>){
    //membuat object
    val mobil =Mobil()

    //memanggil atribut dan memberikan nilai
    mobil.warna = "merah"
    mobil.tahunproduksi=1905
    println("warna : "+mobil.warna)
    println("Tahun produksi : "+mobil.tahunproduksi)
}