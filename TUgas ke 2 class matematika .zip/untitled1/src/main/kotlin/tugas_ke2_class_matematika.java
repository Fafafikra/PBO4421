public class Matematika{
    //Attribut atau variable
    int tambah = 0;
    int kurang = 0;
    int kali = 0;
    int bagi = 0;

    //method pertambahan
    void pertambahan(int a,int b){
        tambah = a+b;
        System.out.println("Pertambahan :"+a+"+"+b+"="+tambah);
    }
    //method pengurangan
    void pengurangan(int a,int b){
        kurang = a-b;
        System.out.println("Pengurangan :"+a+"-"+b+"="+kurang);
    }
    //method perkalian
    void perkalian(int a,int b){
        kali = a*b;
        System.out.println("Perkalian :"+a+"x"+b+"="+kali);
    }
    //method pembagian
    void pembagian(int a,int b){
        bagi = a/b;
        System.out.println("Pembagian : "+a+"/"+b+"="+bagi);
    }

}
