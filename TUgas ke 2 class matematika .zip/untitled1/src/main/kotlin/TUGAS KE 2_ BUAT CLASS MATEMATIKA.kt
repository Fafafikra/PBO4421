class Matematika {
    //Attribut ataw variable
    var tambah = 0
    var kurang = 0
    var kali = 0
    var bagi = 0

    //method pertambahan
    fun pertambahan(a: Int, b: Int) {
        tambah = a + b
        println("Pertambahan :$a+$b=$tambah")
    }

    //method pengurangan
    fun pengurangan(a: Int, b: Int) {
        kurang = a - b
        println("Pengurangan :$a-$b=$kurang")
    }

    //method perkalian
    fun perkalian(a: Int, b: Int) {
        kali = a * b
        println("Perkalian :" + a + "x" + b + "=" + kali)
    }

    //method pembagian
    fun pembagian(a: Int, b: Int) {
        bagi = a / b
        println("Pembagian : $a/$b=$bagi")
    }
}